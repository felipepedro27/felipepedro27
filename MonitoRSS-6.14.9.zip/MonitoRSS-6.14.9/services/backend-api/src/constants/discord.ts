export const DISCORD_API_BASE_URL = 'https://discord.com/api/v9';
export const DISCORD_AUTH_ENDPOINT = '/oauth2/authorize';
export const DISCORD_TOKEN_ENDPOINT = '/oauth2/token';
export const DISCORD_TOKEN_REVOCATION_ENDPOINT = '/oauth2/token/revoke';
