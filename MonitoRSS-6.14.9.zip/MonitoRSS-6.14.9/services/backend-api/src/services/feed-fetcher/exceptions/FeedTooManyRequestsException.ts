import { FeedException } from './FeedException';

export class FeedTooManyRequestsException extends FeedException {}
