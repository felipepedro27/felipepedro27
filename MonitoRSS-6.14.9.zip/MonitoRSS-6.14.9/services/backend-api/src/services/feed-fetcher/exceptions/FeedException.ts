import { StandardException } from '../../../common/exceptions/standard-exception.exception';

export class FeedException extends StandardException {}
