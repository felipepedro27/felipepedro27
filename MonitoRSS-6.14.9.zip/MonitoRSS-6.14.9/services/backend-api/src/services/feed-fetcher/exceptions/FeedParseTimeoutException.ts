import { FeedException } from './FeedException';

export class FeedParseTimeoutException extends FeedException {}
