import { FeedException } from './FeedException';

export class InvalidFeedException extends FeedException {}
