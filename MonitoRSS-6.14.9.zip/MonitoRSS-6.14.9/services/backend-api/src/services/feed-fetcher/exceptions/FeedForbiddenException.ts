import { FeedException } from './FeedException';

export class FeedForbiddenException extends FeedException {}
