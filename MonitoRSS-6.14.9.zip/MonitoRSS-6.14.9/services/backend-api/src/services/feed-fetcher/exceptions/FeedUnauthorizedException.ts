import { FeedException } from './FeedException';

export class FeedUnauthorizedException extends FeedException {}
