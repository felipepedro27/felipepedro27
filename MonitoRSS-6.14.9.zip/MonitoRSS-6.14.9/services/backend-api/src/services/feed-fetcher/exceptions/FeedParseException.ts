import { FeedException } from './FeedException';

export class FeedParseException extends FeedException {}
