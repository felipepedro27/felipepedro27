import { FeedException } from './FeedException';

export class FeedInternalErrorException extends FeedException {}
