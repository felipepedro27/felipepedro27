import { FeedException } from './FeedException';

export class FeedRequestException extends FeedException {}
