export interface DiscordBotUser {
  id: string;
  username: string;
  avatar: string | null;
}
