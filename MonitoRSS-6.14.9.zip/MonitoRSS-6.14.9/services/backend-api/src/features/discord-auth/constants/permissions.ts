export const MANAGE_CHANNEL = BigInt(0x10);
export const SEND_CHANNEL_MESSAGE = BigInt(0x800);
export const NONE = BigInt(0x0);
export const ADMINISTRATOR = BigInt(0x8);
export const VIEW_CHANNEL = BigInt(0x400);
