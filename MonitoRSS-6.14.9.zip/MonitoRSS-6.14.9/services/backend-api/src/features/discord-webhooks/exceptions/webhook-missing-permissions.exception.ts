import { StandardException } from '../../../common/exceptions/standard-exception.exception';

export class WebhookMissingPermissionsException extends StandardException {}
