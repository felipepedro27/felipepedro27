export interface ProfileSettings {
  dateFormat: string;
  dateLanguage: string;
  timezone: string;
}
