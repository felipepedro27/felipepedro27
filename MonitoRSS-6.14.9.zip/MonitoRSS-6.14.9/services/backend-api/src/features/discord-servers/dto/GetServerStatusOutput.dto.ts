export class GetServerStatusOutputDto {
  result: {
    authorized: boolean;
  };
}
