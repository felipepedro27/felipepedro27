import { GetServerOutputDto } from './GetServerOutput.dto';

export class UpdateServerOutputDto extends GetServerOutputDto {}
