export enum FeedStatus {
  OK = 'ok',
  FAILED = 'failed',
  DISABLED = 'disabled',
}
