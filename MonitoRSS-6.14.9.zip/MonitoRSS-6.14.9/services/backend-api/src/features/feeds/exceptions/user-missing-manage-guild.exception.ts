import { AddFeedException } from './add-feed.exception';

export class UserMissingManageGuildException extends AddFeedException {}
