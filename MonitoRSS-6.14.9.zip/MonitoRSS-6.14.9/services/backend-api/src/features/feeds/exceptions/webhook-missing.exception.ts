import { StandardException } from '../../../common/exceptions/standard-exception.exception';

export class WebhookMissingException extends StandardException {}
