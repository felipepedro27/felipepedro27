import { AddFeedException } from './add-feed.exception';

export class MissingChannelPermissionsException extends AddFeedException {}
