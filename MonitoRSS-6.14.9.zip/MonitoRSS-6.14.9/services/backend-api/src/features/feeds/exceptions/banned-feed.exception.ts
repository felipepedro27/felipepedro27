import { AddFeedException } from './add-feed.exception';

export class BannedFeedException extends AddFeedException {}
