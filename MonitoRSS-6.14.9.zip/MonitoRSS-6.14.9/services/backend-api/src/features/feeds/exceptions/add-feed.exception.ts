import { StandardException } from '../../../common/exceptions/standard-exception.exception';

export class AddFeedException extends StandardException {}
