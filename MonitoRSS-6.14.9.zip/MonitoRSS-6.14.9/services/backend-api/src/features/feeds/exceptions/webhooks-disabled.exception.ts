import { StandardException } from '../../../common/exceptions/standard-exception.exception';

export class WebhooksDisabledException extends StandardException {}
