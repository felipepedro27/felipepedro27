import { GetFeedOutputDto } from './GetFeedOutput.dto';

export type UpdateFeedOutputDto = GetFeedOutputDto;
