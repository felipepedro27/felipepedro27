export interface DiscordGuildMember {
  roles: string[];
  user: {
    id: string;
  };
}
