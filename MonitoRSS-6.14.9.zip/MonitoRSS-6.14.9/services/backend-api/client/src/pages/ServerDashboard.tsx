import {
  Box,
} from '@chakra-ui/react';

const ServerDasboard: React.FC = () => (
  <Box>
    Dashboard
  </Box>
);

export default ServerDasboard;
