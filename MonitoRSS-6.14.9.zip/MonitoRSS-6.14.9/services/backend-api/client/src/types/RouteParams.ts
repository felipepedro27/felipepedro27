type RouteParams = 'serverId' | 'feedId';

export default RouteParams;
