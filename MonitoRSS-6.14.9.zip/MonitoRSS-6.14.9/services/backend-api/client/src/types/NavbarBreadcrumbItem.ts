interface NavbarBreadcrumbItem {
  id: string;
  content: React.ReactNode | String;
  enabled?: boolean;
}

export default NavbarBreadcrumbItem;
