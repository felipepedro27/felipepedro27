# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.1.0](https://github.com/MonitoRSS/typescript-template/compare/@monitorss/logger@1.0.1...@monitorss/logger@1.1.0) (2022-01-05)


### Features

* **logger:** Add datadog logger level ([8dab1ff](https://github.com/MonitoRSS/typescript-template/commit/8dab1ff06eeaff6e5de27ec8934abc8c7d3b5e38))






## 1.0.1 (2021-12-02)

**Note:** Version bump only for package @monitorss/logger
